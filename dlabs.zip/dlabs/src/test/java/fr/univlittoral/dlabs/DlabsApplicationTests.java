package fr.univlittoral.dlabs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DlabsApplicationTests {

	@Test
	void contextLoads() {
	}

}
